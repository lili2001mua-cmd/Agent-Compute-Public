<?php
return [
  'host'     => 'localhost',
  'database' => 'hohedoc1_stylist_de',
  'username' => 'hohedoc1_stylist_de',
  'password' => 'رمز_دیتابیس_را_اینجا_بگذارید',
];
