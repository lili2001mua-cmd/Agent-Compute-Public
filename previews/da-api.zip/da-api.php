<?php
return [
  'url'    => 'https://server154gc.axspace.com:2223',
  'user'   => 'hohedoc1',
  'key'    => 'رمز_ورود_DirectAdmin_را_اینجا_بگذارید',
  'domain' => 'hohedoc.ir',
];
